MongoDB Server Documentation
============

This is just some internal documentation.

For the full MongoDB docs, please see [mongodb.org](http://www.mongodb.org/)

* [building](building.md)
